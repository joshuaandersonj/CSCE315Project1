#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
#include <iterator>
#include <vector>
using namespace std;
namespace DatabaseAPI {
	class Attribute {
	public:
		string name;
		string type;
		bool isKey; // added
		bool isUnique; // added
		void setType(string a);
		Attribute();
		Attribute(string nameInput, string typeInput);
		Attribute(string nameInput, string typeInput, bool isKeyInput, bool isUniqueInput);
	};
	class Record {
	public:
		vector<string> attributes;
		Record();
		Record(vector<string> orderedSet);
		int getSize();
		string operator [] (int index);

	};
	class Table {
	public:
		vector<Attribute> attributeDefinitions;
		vector<Record> rows;
		string howdy; //added
		Table();
		Table(vector<Attribute>);
		void addAttribute(string attributeName);
		void addAttribute(Attribute attributeName);
		void removeAttribute(string attributeName);
		void insertRecord(Record input);
		vector<Attribute> getAttributes();
		int getSize();
		vector<Record>::iterator getRecord(int i);
		void setKey(string key);
		//void setKey(vector<string> key);
		void setUnique(string attributeName);
		bool checkUnique(string attributeName);
		void renameAttribute(string attributeName, string newAttributeName);
		Table crossJoin(Table tableA, Table tableB);
		Table naturaljoin(Table tableA, Table tableB); 
		int countAttribute(string attributeName);
		string min(string a);
		string max(string a);
		

	};
	class Database {
	//private:
	public:
		
		template<typename Iterator>
		bool parse_select(Iterator first, Iterator last, vector<int>* selectChoices);
		
		bool parse_where(string where, vector<string>* selectChoices);
		vector<int> parse_where_paren(Table t,string where, vector<string>* selectChoices);
		Table fromTable(string from);
		vector<int> strCompare(Table t,string where, vector<string>* selectChoices);
		 
//	public:
	
		vector<Table> tableObjects;
		vector<string> tableNames;//added
		Database();
		void addTable(Table object,string tableName);
		void removeTable(string tableName);
		void saveDatabase(string fileMame);
		void loadDatabase(string fileName);

		vector<string> listTables(); //changed from string to vector
		vector<Table> getTables();
		//query function
		Table query(string select, string from, string where);
		//delete command
		
		//update/modify command, set attribute could be in the attribute class
		void updateTable(string tableName, string setAttribute);
		
		
		
	};
	
	};
