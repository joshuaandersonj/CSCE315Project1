#include "DatabaseAPI.h"
#include <string>
#include <algorithm>
#include <fstream>
#include <boost/spirit/home/x3.hpp>
#include <boost/config/warning_disable.hpp>
#include <boost/spirit/include/qi_char_class.hpp>
#include <boost/config/warning_disable.hpp>
#include <boost/spirit/home/x3.hpp>
#include <boost/spirit/home/x3/support/ast/position_tagged.hpp>
#include <boost/fusion/include/adapt_struct.hpp>
#include <boost/fusion/include/io.hpp>
#include <regex>

namespace x3 = boost::spirit::x3;
using namespace DatabaseAPI; 
/*struct compareTables
{
	inline bool operator() (const Table& lhs, const Table& rhs)
	{
		return lhs.howdy < rhs.howdy;
	}
};*/
static bool compareTables(Table a, Table b)
{
	int compareInt = a.howdy.compare(b.howdy);
	if (compareInt == -1)
		return true;
	return false;
}
	Database::Database() {
		tableObjects = vector<Table>();
		tableNames = vector<string>();
		std::cout << "Hello\n";
	}
	void Database::addTable(Table object, string tableName) {
		tableObjects.push_back(object);
		if (object.howdy != tableName)
			object.howdy = tableName;
		tableNames.push_back(tableName);
		sort(tableObjects.begin(), tableObjects.end(), compareTables);
		sort(tableNames.begin(), tableNames.end());
		
	}
	void Database::removeTable(string tableName){
		auto it = find_if(tableObjects.begin(), tableObjects.end(), [&tableName](const Table& obj) {return obj.howdy == tableName; });
		if (it != tableObjects.end())
		{
			tableObjects.erase(it);
		}
		//auto it2 = binary_search
		auto it2 = find(tableNames.begin(), tableNames.end(), tableName);
		if (it2 != tableNames.end())
		{
			tableNames.erase(it2);
		}
	}
	vector<string> Database::listTables()
	{
		return tableNames;
	}
	vector<Table> Database::getTables() {
		return tableObjects;
	}
	void printAttributeColumn(vector<Attribute> allA, ostream& os)
	{
		os << "NEWATTCOL\n";
		for(unsigned int i = 0; i < allA.size(); ++i)
		{
			os << allA[i].name << " ";
		}
		os << "\n";
		for (unsigned int i = 0; i < allA.size(); ++i)
		{
			os << allA[i].type << " ";
		}
		os << "\n";
		for (unsigned int i = 0; i < allA.size(); ++i)
		{
			os << allA[i].isKey << " ";
		}
		os << "\n";
		for (unsigned int i = 0; i < allA.size(); ++i)
		{
			os << allA[i].isUnique << " ";
		}
		os << "\n";
	}
	void printRecordToFile(Record r, ostream& os)
	{
		os << "NEWRECORD" << "\n";
		for (int i = 0; i < r.getSize(); ++i)
		{
			os << r.attributes[i] << " ";
		}
		os << "\n";
	}
	void printTableToFile(Table t, ostream& os)
	{
		os << "NEWTABLE" << "\n";
		os << t.howdy << "\n";
		printAttributeColumn(t.getAttributes(), os);
		for (int i = 0; i < t.getSize(); ++i)
		{
			printRecordToFile(t.rows[i], os);
		}
		os << "ENDTABLE" << "\n";
	}
	
	ostream& operator<<(ostream& os, const Database& en){
		
		for(unsigned int i = 0; i < en.tableObjects.size(); ++i)
			printTableToFile(en.tableObjects[i], os);
		
		return os;

	}
	/*ifstream& operator>>(ifstream& is, Database& en) {
		
	}*/
	
	
	void Database::saveDatabase(string fileName)
	{
		ofstream myFile;
		myFile.open(fileName);
		myFile << *this;

	}


	
		
		using x3::_attr;

		struct print_action
		{
			template <typename Context>
			void operator()(Context const& ctx) const
			{
				std::cout << _attr(ctx) << std::endl;
			}
		};
	

	
	void Database::loadDatabase(string fileName)
	{
		Database db = Database();
		Table t = Table();
		string tableName = "";
		bool isTable;
		bool isRow;
		bool isAttributeColumn;
		bool passed;
		int caseD = 0;
		ifstream myFile;
		myFile.open(fileName);
		string temp;
		while (getline(myFile, temp))
		{
			
			
			if (temp.compare("NEWTABLE") == 0) {
				t = Table();
				tableName = "";
				isTable = true;
				isRow = false;
				isAttributeColumn = false;
				passed = true;
				caseD = 1;
			}
			else if (temp.compare("NEWATTCOL") == 0)
			{
				isTable = false;
				isRow = false;
				isAttributeColumn = true;
				passed = true;
				caseD = 2;
			}
			else if (temp.compare("NEWRECORD") == 0)
			{
				isTable = false;
				isRow = true;
				isAttributeColumn = false;
				passed = true;
				caseD = 3;
			}
			else if (temp.compare("ENDTABLE") == 0)
			{
				passed = true;
				caseD = 4;
			}

			if (passed)
			{
				string line;
				string token;
				bool isError = true;
				if(caseD != 4)
				if (getline(myFile, line))
					isError = false;
				stringstream linestream(line);
				//vector<string>
				switch (caseD) {
				case 1:
				{
					if (isError)
						return;
					//NEW TABLE
					string name;
					t.howdy = line;
					tableName = line;
					caseD = 0;
					passed = false;
					break;
				}
				case 2:
				{
					//ATTRIBUTE COLUMN
					if (isError)
						return;
					string name;
					vector<Attribute> cols;
					while (linestream >> name)
					{
						Attribute a = Attribute();
						a.name = name;
						cols.push_back(a);
					}
					if (getline(myFile, line))
					{

						linestream = stringstream(line);
						int count = 0;
						while (linestream >> name)
						{
							cols[count].setType(name);
							count++;
						}
					}
					else
					{
						return;
					}
					if (getline(myFile, line))
					{
						linestream = stringstream(line);
						int count = 0;
						bool isKey = 0;
						while (linestream >> isKey)
						{
							cols[count].isKey = isKey;
							count++;
						}
					}
					else {
						return;
					}
					if (getline(myFile, line))
					{
						linestream = stringstream(line);
						int count = 0;
						bool isUniq = 0;
						while (linestream >> isUniq)
						{
							cols[count].isUnique = isUniq;
							count++;
						}
					}
					else
					{
						return;
					}
					t.attributeDefinitions = cols;
					caseD = 0;
					passed = false;
					break;
				}
				case 3:
				{
					//RECORD
					if (isError)
						return;
					vector<string> orderedSet;
					//getline(myFile, line);
					linestream = stringstream(line);
					string att;
					while (linestream >> att)
					{
						orderedSet.push_back(att);
					}
					Record r = Record(orderedSet);
					t.insertRecord(r);
					caseD = 0;
					passed = false;
					break;
				}
				case 4:
				{
					//ENDTABLE
					db.addTable(t,tableName);
					caseD = 0;
					passed = false;
					break;

				}
				default:
				{

					caseD = 0;
					passed = false;
					break;
				}
				}
			}
		}
		*this = db;
		return;
		/*
			//istream(temp);
			using boost::spirit::x3::int_;
			using boost::spirit::x3::parse;
			using x3::lit;
			//using client::print_action;

			{ // example using function object

				char const *first = "{43}", *last = first + std::strlen(first);
				parse(first, last, '{' >> int_[print_action()] >> '}');
			}

			{ // example using C++14 lambda

				using boost::spirit::x3::_attr;
				char const *first = "{44}", *last = first + std::strlen(first);
				auto f = [](auto& ctx) { std::cout << _attr(ctx) << std::endl; };
				parse(first, last, '{' >> int_[f] >> '}');
			}

			*/
		}
	/*void Database::loadDatabase(string fileName)
	{
		Database a = Database();
		Table t = Table();
		Record r = Record();
		bool isTable;
		bool isRow;
		bool isAttributeColumn;
		string line;
		ifstream myFile;
		myFile.open(fileName);
		while (getline(myFile, line))
		{
			std::stringstream   linestream(line);
			std::string         data;
			

			// If you have truly tab delimited data use getline() with third parameter.
			// If your data is just white space separated data
			// then the operator >> will do (it reads a space separated word into a string).
			//std::getline(linestream, data, '\t');  // read up-to the first tab (discard tab).

			// Read the integers using the operator >>
			namespace x3 = boost::spirit::x3;
			namespace ascii = boost::spirit::x3::ascii;
			using x3::int_;
			using x3::lit;
			using x3::double_;
			using x3::lexeme;
			using ascii::char_;
			auto iter = line.begin();
			auto end_iter = line.end();
			Record r;
			//x3::parse(iter, end_iter, +(+char_(("a-z"))) >> ' ' >> (+char_("a-z")));
			vector<string> result;
			
			

		}
	}*/
	
	/*The query command should be a member function from the database. It will return a table. The
		query command should take in three arguments, a SELECT argument, a FROM argument, and a
			WHERE argument.Each argument should be specified as a string to be processed.These three
			arguments should have the following properties :
		� In the SELECT argument, allow either
			o A list of which attributes names to keep.These should be a list, in order, of the
			o An * to keep all attributes.
			� In the FROM argument
			o A single table name
			� In the WHERE argument, references to the attribute names.
			o Comparisons of =, &lt; &gt; , &gt; , &lt; , &gt; =, &lt; = (string comparisons)
			o * An IN operator (given the name of a table with only one attribute)
			o * An EXISTS operator (given the name of a table with only one
				attribute) o AND, OR, and NOT
			o Parentheses.Parentheses can be nested.
			o * ALL(given the name of a table with only one attribute)
			o * ANY(given the name of a table with only one attribute)

			Note that the WHERE clause(and to a lesser degree the SELECT clause) will require parsing.*/
		//QUERY STARTS HERE
		template <typename Iterator>
		bool Database::parse_select(Iterator first, Iterator last, vector<int>* selectChoices)
		{
			using boost::spirit::x3::char_;
			using boost::spirit::x3::_attr;
			using boost::spirit::x3::phrase_parse;
			using boost::spirit::x3::ascii::space;
			using boost::spirit::x3::int_;
			auto assign = [&](auto& ctx) {selectChoices->push_back(_attr(ctx)); };
			auto all = [&](auto& ctx) {selectChoices->push_back(-1); };
			bool r = x3::phrase_parse(first, last,
				(
					char_('*')[all] | *(int_[assign] % ',')
					),
			space);
			if (!r || first != last) // fail if we did not get a full match
				return false;
				
				return r;
		}
		
		namespace client {
			namespace ast
			{
				///////////////////////////////////////////////////////////////////////////
				//  Our employee struct
				///////////////////////////////////////////////////////////////////////////
				struct equal
				{
					int age;
					std::string forename;
					//std::string surname;
					//double salary;
				};
				using boost::fusion::operator<<;
				struct Greater
				{
					int age;
					std::string attributeDef;
				//	std::string attributeVal;
				};
				struct Less
				{
					int age;
					std::string attributeDef;
					//	std::string attributeVal;
				};
				struct GreaterEq
				{
					int age;
					std::string attributeDef;
					//	std::string attributeVal;
				};
				struct LessEq
				{
					int age;
					std::string attributeDef;
					//	std::string attributeVal;
				};
				using boost::fusion::operator<<;
			}
		}

		// We need to tell fusion about our employee struct
		// to make it a first-class fusion citizen. This has to
		// be in global scope.

		BOOST_FUSION_ADAPT_STRUCT(client::ast::equal,
			age, forename/*, surname, salary*/
		);
		BOOST_FUSION_ADAPT_STRUCT(client::ast::Greater, age,
			attributeDef//, attributeVal
		);
		BOOST_FUSION_ADAPT_STRUCT(client::ast::Less, age,
			attributeDef//, attributeVal
		);
		BOOST_FUSION_ADAPT_STRUCT(client::ast::LessEq, age,
			attributeDef//, attributeVal
		);
		BOOST_FUSION_ADAPT_STRUCT(client::ast::GreaterEq, age,
			attributeDef//, attributeVal
		)

			namespace client
		{
			///////////////////////////////////////////////////////////////////////////////
			//  Our employee parser
			///////////////////////////////////////////////////////////////////////////////
			namespace parser
			{
				namespace x3 = boost::spirit::x3;
				namespace ascii = boost::spirit::x3::ascii;

				using x3::int_;
				using x3::lit;
				using x3::double_;
				using x3::lexeme;
				using ascii::char_;

				x3::rule<class equal, ast::equal> const equal = "equal";

				x3::rule<class Greater, ast::Greater> const Greater = "Greater";

				x3::rule<class Less, ast::Less> const Less = "Less";

				x3::rule<class LessEq, ast::LessEq> const LessEq = "LessEq";

				x3::rule<class GreaterEq, ast::GreaterEq> const GreaterEq = "GreaterEq";

				auto const quoted_string = lexeme['"' >> +(char_ - '"') >> '"'];

				auto const equal_def =
					lit("equals")
					>> '{'
					>> int_ >> ','
					>> quoted_string
					>> '}'
					;
				auto const Greater_def =
					lit("greater")
					>> '{'
					>> int_ >> ','
					>> quoted_string 
					>> '}'
					;
				auto const GreaterEq_def =
					lit("greaterEqual")
					>> '{'
					>> int_ >> ','
					>> quoted_string
					>> '}'
					;
				auto const Less_def =
					lit("less")
					>> '{'
					>> int_ >> ','
					>> quoted_string
					>> '}'
					;
				auto const LessEq_def =
					lit("lessEqual")
					>> '{'
					>> int_ >> ','
					>> quoted_string
					>> '}'
					;

				BOOST_SPIRIT_DEFINE(equal,Greater,Less,LessEq,GreaterEq);
				
				
			}
		}
		//template <typename Iterator>
		//T handler, returns true if valid input
		bool Database::parse_where(string where, vector<string>* selectChoices)
		{
			/*auto greater = rule<class greater, std::pair<std::string, std::string>() = (+(alpha | digit | punct) >> '>' >> (alpha | digit | punct));
			auto less = rule<class less, std::pair<std::string, std::string>() = (+(alpha | digit | punct) '<' (alpha | digit | punct));
			auto less_equal = rule<class less_equal, std::pair<std::string, std::string>() = (+(alpha | digit | punct) '<=' (alpha | digit | punct));
			auto greater_equal = rule<class greater_equal, std::pair<std::string, std::string>() = (+(alpha | digit | punct) '>=' (alpha | digit | punct));

			//auto equals_def = rule<class equals>() = (+(alnum | punct)[push_back(phoenix::ref(selectChoices), _1)] char_('=')[push_back(phoenix::ref(selectChoices), _1] + (alnum)[push_back(phoenix::ref(selectChoices), _1)]);
			//auto equal_passed = [&](auto& ctx) {
			//		selectChoices.push_back(_attr(ctx))};
				//auto all = [&](auto& ctx) {selectChoices.push_back(-1)};
			//	bool r = x3::phrase_parse(first, last,
			//		equals | greater | less | less_equal | greater_equal, space);
			*/
			/*	using boost::spirit::x3::char_;
				using boost::spirit::x3::_attr;
				using boost::spirit::x3::phrase_parse;
				using boost::spirit::x3::ascii::space;
			//	using boost::spirit::x3::literal_string;
				using boost::spirit::x3::alpha;
			//	using boost::spirit::x3::punct;
			//	using boost::spirit::x3::digit;
				using boost::spirit::x3::alnum;
			//	using phoenix::push_back;
				using boost::spirit::x3::string;
				using boost::spirit::lit;

				auto push_back = [&](auto& ctx) {selectChoices->push_back((_attr(ctx))); };
				bool r = x3::phrase_parse(first, last,
					(
						lit('a', 'z') >> +lit('a','z')[push_back] >> char_('=')[push_back] >> string[push_back]
						), space);
				if (!r || first != last) // fail if we did not get a full match*/
			std::cout << "/////////////////////////////////////////////////////////\n\n";
			std::cout << "\t\tA query parser for Spirit...\n\n";
			std::cout << "/////////////////////////////////////////////////////////\n\n";

			
			std::cout << "Type [q or Q] to quit\n\n";

			using boost::spirit::x3::ascii::space;
			typedef std::string::const_iterator iterator_type;
			using client::parser::equal;
			using client::parser::Greater;
			using client::parser::GreaterEq;
			using client::parser::Less;
			using client::parser::LessEq;
			std::string str = where;


			//	if (str.empty() || str[0] == 'q' || str[0] == 'Q')
				//	break;

			client::ast::equal eq;
			eq.age = -2;
			eq.forename = "";
			
			client::ast::Greater gr;
			gr.age = -2;
			gr.attributeDef = "";

			client::ast::GreaterEq grEq;
			grEq.age = -2;
			grEq.attributeDef = "";

			client::ast::LessEq leEq;
			leEq.age = -2;
			leEq.attributeDef = "";

			client::ast::Greater le;
			le.age = -2;
			le.attributeDef = "";
			
			
			iterator_type iter = str.begin();
			iterator_type const end = str.end();
			tuple<client::ast::equal, client::ast::Greater> a;
			bool r = phrase_parse(iter, end, equal, space, eq);

			iterator_type iter2 = str.begin();
			iterator_type const end2 = str.end();
			bool s =  phrase_parse(iter2, end2, Greater, space, gr);

			iterator_type iter3 = str.begin();
			iterator_type const end3 = str.end();
			bool t = phrase_parse(iter3, end2, Less, space, le);

			iterator_type iter4 = str.begin();
			iterator_type const end4 = str.end();
			bool u = phrase_parse(iter4, end2, LessEq, space, leEq);

			iterator_type iter5 = str.begin();
			iterator_type const end5 = str.end();
			bool v = phrase_parse(iter5, end2, GreaterEq, space, grEq);
			

			

			if ((r && iter == end) || (s && iter2 == end) || (t && iter3 == end) || (u && iter4 == end) || (v && iter5 == end))
			{
				std::cout << boost::fusion::tuple_open('[');
				std::cout << boost::fusion::tuple_close(']');
				std::cout << boost::fusion::tuple_delimiter(", ");

				std::cout << "-------------------------\n";
				std::cout << "Parsing succeeded\n";
			//	std::cout << "got: " << eq << std::endl;
				std::cout << "\n-------------------------\n";
				if (r) {
					selectChoices->push_back(to_string(eq.age));
					selectChoices->push_back(eq.forename);
					selectChoices->push_back("=");

				}
				else if (s) {
					selectChoices->push_back(to_string(gr.age));
					selectChoices->push_back(gr.attributeDef);
					selectChoices->push_back(">");
				}
				else if (t) {
					selectChoices->push_back(to_string(le.age));
					selectChoices->push_back(le.attributeDef);
					selectChoices->push_back("<");
				}
				
				
				else if (u) {
					selectChoices->push_back(to_string(leEq.age));
					selectChoices->push_back(leEq.attributeDef);
					selectChoices->push_back(":");
				}

				else if (v) {
					selectChoices->push_back(to_string(grEq.age));
					selectChoices->push_back(grEq.attributeDef);
					selectChoices->push_back("?");
				}
				return true;
			}
			else
			{
				std::cout << "-------------------------\n";
				std::cout << "Parsing failed\n";
				std::cout << "-------------------------\n";
			}
			return false;
			//	return r;
		}
		// N T Handler
		vector<int> invertSelectChoices(vector<int> selectChoices, int attributeDefinitions_Size)
		{
			vector<int> output = vector<int>();
			for (int i = 0; i < attributeDefinitions_Size;++i)
			{
				output.push_back(i);
			}
				for (auto j = selectChoices.begin(); j != selectChoices.end(); ++j)
				{
					for (auto i = output.begin(); i != output.end(); ++i)
					{
						if (*i == *j)
						{
							output.erase(i);
							break;
						}
					}
				}
				return output;
		}
		//Turns the string vector of parse_where into a vector of ints corresponding the to rows that work (Probably I forget)
		vector<int> Database::strCompare(Table t, string where, vector<string>* selectChoices)
		{
			 
			parse_where(where, selectChoices);
			stringstream geek(selectChoices->at(0));
			int colCompareLoc;
			geek >> colCompareLoc;
			Attribute whereToCompare = t.attributeDefinitions[colCompareLoc];
			vector<int> newRows = vector<int>();
			string formatDecision = selectChoices->at(2);
			for (auto i = 0; i < t.rows.size(); ++i)
			{

				switch (formatDecision[0])
				{

				case '=':
				{
					if (selectChoices->at(1).compare(t.rows[i].attributes[colCompareLoc]) == 0) {
						newRows.push_back(i);
						
					}


					break;
				}
				case '<':
				{
					if (selectChoices->at(1).compare(t.rows[i].attributes[colCompareLoc]) < 0)
						newRows.push_back(i);
					break;
				}
				case '>':
				{
					if (selectChoices->at(1).compare(t.rows[i].attributes[colCompareLoc]) > 0)
						newRows.push_back(i);
					break;
				}
				case '?':
				{
					if (selectChoices->at(1).compare(t.rows[i].attributes[colCompareLoc]) > 0)
						newRows.push_back(i);
					else if (selectChoices->at(1).compare(t.rows[i].attributes[colCompareLoc]) == 0)
						newRows.push_back(i);
					break;
				}
				case ':':
				{
					if (selectChoices->at(1).compare(t.rows[i].attributes[colCompareLoc]) < 0)
						newRows.push_back(i);
					else if (selectChoices->at(1).compare(t.rows[i].attributes[colCompareLoc]) == 0)
						newRows.push_back(i);
					break;
				}
				default:
					//error = true;
					
					break;
				}
			}
			return newRows;
		}
		//Replaces every instance of the string in search
		void ReplaceStringInPlace(std::string& subject, const std::string& search, const std::string& replace) {
			size_t pos = 0;
			while ((pos = subject.find(search, pos)) != std::string::npos) {
				subject.replace(pos, search.length(), replace);
				pos += replace.length();
			}
		}
		//Replaces the first instance of the string in search
		void ReplaceStringInPlace2(std::string& subject, const std::string& search, const std::string& replace) {
			size_t pos = 0;
				if((pos = subject.find(search, pos)) != std::string::npos) {
				subject.replace(pos, search.length(), replace);
				pos += replace.length();
			}
		}
		//grabs the number from the token
		int grabNumber(string input)
		{
			string input2;
			input2.push_back(input[1]); //string containing the number
			int Result;//number which will contain the result

			stringstream convert(input2);
			convert >> Result;
			return Result;
		}
		//Handles T A T
		vector<int> A_case_handle(int left, int right, vector<vector<int>>* inputTokens)
		{
			vector<int> result = vector<int>();
			for (int i = 0; i < (*inputTokens)[left].size(); ++i)
			{
				for (int j = 0; i < (*inputTokens)[right].size(); ++j)
				{
					if ((*inputTokens)[left][i] == ((*inputTokens)[right][j]))
					{
						result.push_back((*inputTokens)[left][i]);
					}
				}
			}
			return result;
		}
		//Handles T O T
		vector<int> O_case_handle(int left, int right, vector<vector<int>>* inputTokens)
		{
			vector<int> vec = vector<int>();
			vec = (*inputTokens)[left];
			vec.insert(vec.end(), (*inputTokens)[right].begin(), (*inputTokens)[right].end());
			sort(vec.begin(), vec.end());
			vec.erase(unique(vec.begin(), vec.end()), vec.end());
			return vec;
		}
		//Recursive function that calls itself every parenthesis to process the tokens inside the parenthesis
		//Returns the row numbers that need to be taken from
		vector<int> scanner(Table t, string tokened, vector<vector<int>> inputTokens)
		{
			//Precedence P N (A O)
			//Given token string with P N (A O) T(number) tokens
			//T(number) - already passed into parse_where with the number corresponding to index in inputTokens
			//Table t - Table that corresponds to the FROM specified in Query
			vector<int> output = vector<int>();
			auto numRecords = t.getSize();
			//Parenthesis
			//Left -> Right Dealing with parenthesis as I go
			//Encounter P start looking for E
			//Encounter Another P, Call the function again with left side removed
			// P T E A P T E E
			//Find E Call scanner from P to E
			//RecursionOut = scanner(P to E)
			//output = output.insert(output.end(),RecursionOut.begin(),RecursionOut.end());

			//Base Case No Parenthesis
			// T A T O T Left -> Right reading tokens and such
			//return output
			//cases for not : N P , N T
			//cases for and : E A P, E A T, T A P, T A T
			//cases for or : E O P, E O T, T O P, T O T
			stringstream tokenSS = stringstream(tokened);
			std::string input = "";
			regex s("[P][ ][^PE][ ][E]");
			smatch m;
			regex_search(tokened, m, s);

			while (m[0] != "")
			{
				string toScanner = m[0].str();
				toScanner = toScanner.substr(1, toScanner.size() - 1);
				output.insert(output.end(), scanner(t, toScanner, inputTokens).begin(), scanner(t, toScanner, inputTokens).end());
				//ReplaceStringInPlace2(tokened, m[0], "");
				regex_search(tokened, m, s);
			}
			string T1 = "";
			while (tokenSS >> input)
			{
				vector<char> parseChars = vector<char>();

				switch (input[0])
				{
				case 'N':
				{
					tokenSS >> input;
					string input2;
					input2.push_back(input[1]); //string containing the number
					int Result;//number which will contain the result

					stringstream convert(input2);
					convert >> Result;
					inputTokens[Result] = invertSelectChoices(inputTokens[Result], numRecords);
					string input3 = "N " + input;

					ReplaceStringInPlace2(tokened, input3, input);
					tokenSS = stringstream(tokened);

					break;
				}
				case 'T':
				{
					T1 = input;
					break;
				}
				case 'A':
				{
					tokenSS >> input;
					if (input[0] != 'N')
					{
						inputTokens[grabNumber(input)] = A_case_handle(grabNumber(T1), grabNumber(input), &inputTokens);
						string replace = T1 + " A " + input;
						T1 = "";
						ReplaceStringInPlace2(tokened, replace, input);
						tokenSS = stringstream(tokened);
						break;
					}
					else
					{
						tokenSS >> input;
						string input2;
						input2.push_back(input[1]); //string containing the number
						int Result;//number which will contain the result

						stringstream convert(input2);
						convert >> Result;
						inputTokens[Result] = invertSelectChoices(inputTokens[Result], numRecords);
						inputTokens[Result] = A_case_handle(grabNumber(T1), Result, &inputTokens);
						string input3 = T1 + " A N " + input;
						ReplaceStringInPlace2(tokened, T1, "");
						ReplaceStringInPlace2(tokened, "A", "");
						ReplaceStringInPlace2(tokened, input3, input);
						tokenSS = stringstream(tokened);
						T1 = "";
						break;
					}



				}
				case 'O':
				{
					tokenSS >> input;
					if (input[0] != 'N')
					{
						inputTokens[grabNumber(input)] = O_case_handle(grabNumber(T1), grabNumber(input), &inputTokens);
						string replace = T1 + " O " + input;
						T1 = "";
						ReplaceStringInPlace2(tokened, replace, input);
						tokenSS = stringstream(tokened);
						break;
					}
					else
					{
						tokenSS >> input;
						string input2;
						input2.push_back(input[1]); //string containing the number
						int Result;//number which will contain the result

						stringstream convert(input2);
						convert >> Result;
						inputTokens[Result] = invertSelectChoices(inputTokens[Result], numRecords);
						inputTokens[Result] = O_case_handle(grabNumber(T1), Result, &inputTokens);
						string input3 = T1 + " O N " + input;
						//ReplaceStringInPlace2(tokened, T1, "");
						//ReplaceStringInPlace2(tokened, "O", "");
						ReplaceStringInPlace2(tokened, input3, input);
						tokenSS = stringstream(tokened);
						T1 = "";
						break;
					}



				}


				}


			}
			return inputTokens[grabNumber(T1)];
		}
		//Tokenizes the input of where P = ( , E = ), T<number> = Processed Input of parse_where(individual input), A = AND, O = OR
		vector<int> Database::parse_where_paren(Table t,string where, vector<string>* selectChoices)
		{
			//NOT((equals{ 0, "Joshua" }) AND(equals{ 1, "James" }))
			//N P P T E A P T E E
			vector<vector<int>> tokens;
			
			std::string test = where;
			std::smatch m;
			std::regex par("[(]{1}[^()][)]{1}");
			std::regex_search(test, m, par);
			std::regex e("((equals|lessEqual|greaterEqual|greater|less) ([{]([^}]*)[}]))");
			int count = 0;
			
			while (true)
			{
				vector<int> tokenOutput;
				vector<string> outputOfParse_where;
				string TplusCount = "T" + to_string(count);
				std::regex_search(test, m , e );
				if (parse_where(*m.begin(), &outputOfParse_where))
				{
					tokenOutput = strCompare(t, "", &outputOfParse_where);
					tokens.push_back(tokenOutput);
					std::regex_replace(test, e, TplusCount);
					count++;
				}
				else
				{
					break;
				}
			}
			//std::regex andOrNotReplacer("AND|OR|NOT")
			ReplaceStringInPlace(test, "AND", "A");
			ReplaceStringInPlace(test, "OR", "O");
			ReplaceStringInPlace(test, "NOT", "N");
			ReplaceStringInPlace(test, "(", "P");
			ReplaceStringInPlace(test, ")", "E");
			vector<int> output = scanner(t,test, tokens);
			return output;
			//|(AND)|(OR)|(NOT)
		/*	if (m.size() == 0)
			{
				std::regex_search(test, m, e);
			}
			else
			{
				// a = ((equals {0, "Joshua"}) AND (equals {1, "James"}))
				parse_where_paren(where, selectChoices);
			}*/
		}
		
		
		Table Database::fromTable(string from)
		{
			vector<string>::iterator it = find(tableNames.begin(), tableNames.end(), from);
			_int64 index = it - tableNames.begin();
			return tableObjects[index];
		}
		Table Database::query(string select, string from, string where)
		{
			Table t = fromTable(from);
			vector<string>::iterator it = find(tableNames.begin(), tableNames.end(), from);
			vector<string>* whereOut = new vector<string>();
			vector<int>* selectChoices = new vector<int>();
			vector<int> rowChoices = vector<int>();
			Table newt = Table();
			if (it != tableNames.end())
				if (parse_select(select.begin(), select.end(), selectChoices))
				{
					rowChoices = parse_where_paren(t, where, whereOut);
					
					//Create the new table (newt) from the selectChoices(Columns to keep) and rowChoices(rows to keep)

					//Fills attributeDefinitions with select's attributes to keep
					for (int j = 0; j < selectChoices->size(); ++j)
					{
						newt.attributeDefinitions.push_back(t.attributeDefinitions[(*selectChoices)[j]]);
					}

					//Fill rows with correct columns from select and where's output
					for (int i = 0; i < rowChoices.size(); ++i)
					{
						Record r = Record();
						for (int j = 0; j < selectChoices->size(); ++j)
						{
							
							r.attributes.push_back(t.rows[rowChoices[i]].attributes[(*selectChoices)[j]]);
						}
						newt.insertRecord(r);
					}
					return newt;
				}
			return newt;
		}

		/*Table Database::query(string select, string from, string where)
		{
			
			vector<string>::iterator it = find(tableNames.begin(), tableNames.end(), from);
			_int64 index = it - tableNames.begin();
			vector<int>* selectChoices = new vector<int>();
			if(it != tableNames.end())
			if (parse_select(select.begin(), select.end(), selectChoices))
			{
				vector<string>* whereOut = new vector<string>();
				if (parse_where(where, whereOut))
				{
					sort(selectChoices->begin(), selectChoices->end());
					
					vector<Attribute> newAttributes;
					vector<int> selectChoices2 = *selectChoices;
					Table t = tableObjects[index];
					Table newt = Table();
					bool error = false;
					int colSize = static_cast<int>(t.attributeDefinitions.size());
					if (selectChoices2[0] != -1)
					{
						for (auto i = 0; i < selectChoices->size(); ++i)
						{
							if (selectChoices2[i] < colSize && (selectChoices2[i] >= 0))
							{

							}
							else
							{
								error = true;
								break;

							}
						}
					}
					if (error)
						cout << "Error occurred";
					else
					{
						stringstream geek(whereOut->at(0));
						int colCompareLoc;
						geek >> colCompareLoc;
						Attribute whereToCompare = t.attributeDefinitions[colCompareLoc];
						vector<Record> newRows = vector<Record>();
						string formatDecision = whereOut->at(2);
						for (auto i = 0; i < t.rows.size(); ++i)
						{

							switch (formatDecision[0])
							{

							case '=':
							{
								if (whereOut->at(1).compare(t.rows[i].attributes[colCompareLoc]) == 0)
									newRows.push_back(t.rows[i]);


								break;
							}
							case '<':
							{
								if (whereOut->at(1).compare(t.rows[i].attributes[colCompareLoc]) < 0)
									newRows.push_back(t.rows[i]);
								break;
							}
							case '>':
							{
								if (whereOut->at(1).compare(t.rows[i].attributes[colCompareLoc]) > 0)
									newRows.push_back(t.rows[i]);
								break;
							}
							case '?':
							{
								if (whereOut->at(1).compare(t.rows[i].attributes[colCompareLoc]) > 0)
									newRows.push_back(t.rows[i]);
								else if (whereOut->at(1).compare(t.rows[i].attributes[colCompareLoc]) == 0)
									newRows.push_back(t.rows[i]);
								break;
							}
							case ':':
							{
								if (whereOut->at(1).compare(t.rows[i].attributes[colCompareLoc]) < 0)
									newRows.push_back(t.rows[i]);
								else if (whereOut->at(1).compare(t.rows[i].attributes[colCompareLoc]) == 0)
									newRows.push_back(t.rows[i]);
								break;
							}
							default:
								error = true;
								break;
							}
						}
						if (error)
							cout << "error type 2";
						else
						{
							newt.attributeDefinitions = t.attributeDefinitions;
							newt.rows = newRows;
							if (selectChoices2[0] != -1)
							{
								for (auto i = 0; i < t.attributeDefinitions.size(); ++i)
								{
									bool remove = true;
									int j;
									
									for (j = 0; j < selectChoices2.size(); ++j)
									{
										if (selectChoices2[j] < colSize && (selectChoices2[j] >= 0))
										{
											if (selectChoices2[j] == i)
												remove = false;
											//newAttributes.push_back(t.attributeDefinitions[selectChoices2[i]]);
										}
										else
										{
											error = true;
											break;

										}
									}

										if (remove)
										{
											newt.removeAttribute(t.attributeDefinitions[i].name);
											
										}
										else
										{
											remove = true;
										}
										
									

								}
							}

							
						}
						return newt;
					}

					
				}
			}
			return Table();
		}*/
//QUERY ENDS HERE
		Table::Table() {
			vector<Attribute> temp = vector<Attribute>();
			vector<Record> temp2 = vector<Record>();
			attributeDefinitions = temp;
			rows = temp2;
		}
		
		void Table::insertRecord(Record input)
		{
			rows.push_back(input);
		}

	// default constructor
	Record::Record() {
		attributes = vector<string>();
	}

	// constructor with arguments
	Record::Record(vector<string> orderedSet) {
		attributes = orderedSet;
	}

	// return number of columns in a record
	int Record::getSize() {
		auto recordSize = attributes.size();
		return static_cast<int>(recordSize);
	}

	string Record::operator[] (int index) {
		return attributes[index];
	}

	Attribute::Attribute() {
		name = "";
		type = "";
		isKey = false;
		isUnique = false;
		std::cout << "hello\n";
	}
	Attribute::Attribute(string nameInput, string typeInput, bool isKeyInput, bool isUniqueInput)
	{
		name = nameInput;
		type = typeInput;
		isKey = isKeyInput;
		isUnique = isUniqueInput;
	}
	Attribute::Attribute(string nameInput, string typeInput)
	{
		name = nameInput;
		type = typeInput;
		isKey = false;
		isUnique = false;
	}
	void Attribute::setType(string a) {
		std::cout << "hello\n";
	}


	vector<Record>::iterator Table::getRecord(int i)
	{
		vector<Record>::iterator it = rows.begin();
		advance(it, i);
		return it;
	}
/*	Table::Table() {
		vector<Attribute> temp = vector<Attribute>();
		vector<Record> temp2 = vector<Record>();
		attributeDefinitions = temp;
		rows = temp2;
		std::cout << "hello\n";
	}*/
	
	Table Table::naturaljoin(Table tableA, Table tableB)
	{
		Table joinedTable;
		vector<Attribute> aAttributes = tableA.getAttributes();
		vector<Attribute> bAttributes = tableB.getAttributes();
		vector<string> keyAttributeNames;
		vector<int> matchIndecies;
		for (int i = 0; i < bAttributes.size(); i++)
		{
			if (bAttributes[i].isKey == true)
			{
				keyAttributeNames.push_back(bAttributes[i].name);
				matchIndecies.push_back(i);
			}
		}
		if (keyAttributeNames.empty())
		{
			cout << "Second table has no key attributes" << endl;
			return joinedTable;
		}
		else
		{
			bool hasMatchingAttributes = false;
			vector<string> matchingAttributes;
			vector<int> aMatchingIndices;
			for (int i = 0; i < aAttributes.size(); i++)
			{
				for (int j = 0; j < keyAttributeNames.size(); j++)
				{
					if (aAttributes[i].name == keyAttributeNames[j])
					{
						hasMatchingAttributes = true;
						matchingAttributes.push_back(keyAttributeNames[j]);
						aMatchingIndices.push_back(i);
					}
				}
			}
			if (hasMatchingAttributes)
			{
				joinedTable = tableA;
				vector<int> nonMatchingIndices;
				vector<int> bMatchingIndices;
				for (int i = 0; i < bAttributes.size(); i++)
				{
					bool noMatch = true;
					for (int j = 0; j < matchingAttributes.size(); j++)
					{
						if (bAttributes[i].name == matchingAttributes[j])
						{
							noMatch = false;
							bMatchingIndices.push_back(i);
						}
					}
					if (noMatch)
					{
						joinedTable.addAttribute(bAttributes[i].name);
						nonMatchingIndices.push_back(i);
					}
				}
				for (int i = 0; i < joinedTable.getSize(); i++)
				{
					for (int j = 0; j < tableB.getSize(); j++)
					{
						bool correspondingRow = true;
						for (int k = 0; k < aMatchingIndices.size(); k++)
						{
							for (int l = 0; l < bMatchingIndices.size(); l++)
							{
								if (joinedTable.rows[i].attributes[aMatchingIndices[k]] != tableB.rows[j].attributes[bMatchingIndices[l]])
								{
									correspondingRow = false;
								}
							}
						}
						if (correspondingRow)
						{
							for (int m = 0; m < bAttributes.size(); m++)
							{
								bool notMatchingAttribute = true;
								for (int n = 0; n < bMatchingIndices.size(); n++)
								{
									if (m = bMatchingIndices[n])
									{
										notMatchingAttribute = false;
									}
								}
								if (notMatchingAttribute)
								{
									joinedTable.rows[i].attributes.push_back(tableB.rows[j].attributes[m]);
								}
							}
						}
					}
				}
				return joinedTable;
			}
			else
			{
				cout << "First table has no attributes that match key attributes of the second table" << endl;
				return joinedTable;
			}
		}
	}
	
/*	Record::Record() {
		attributes = vector<string>();

		std::cout << "hello\n";
	}
	int Record::getSize() {
		std::cout << "hello\n";
		return 0;
	}
	Attribute::Attribute() {
		name = "";
		type = "";
		isKey = false;
		isUnique = false;
		std::cout << "hello\n";
	}
	void Attribute::setType(string a) {
		std::cout << "hello\n";
	}

	Table::Table()
	{
	}
	*/
	Table::Table(vector<Attribute> attributes)
	{
		attributeDefinitions = attributes;
	}

	void Table::addAttribute(string attributeName)
	{
		bool addAttributeToTable = true;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName == attributeDefinitions[i].name)
				{
					addAttributeToTable = false;
				}
			}
		}
		if (addAttributeToTable)
		{
			Attribute newAttribute=Attribute();
			newAttribute.name = attributeName;
			attributeDefinitions.push_back(newAttribute);
			if (!rows.empty())
			{
				for (int i = 0; i < rows.size(); i++)
				{
					rows[i].attributes.push_back("NULL");
				}
			}
		}
		else
		{
			cout << "Attribute already in table" << endl;
		}
	}

	void Table::addAttribute(Attribute attributeName)
	{
		bool addAttributeToTable = true;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName.name == attributeDefinitions[i].name)
				{
					addAttributeToTable = false;
				}
			}
		}
		if (addAttributeToTable)
		{
			attributeDefinitions.push_back(attributeName);
			if (!rows.empty())
			{
				for (int i = 0; i < rows.size(); i++)
				{
					rows[i].attributes.push_back("NULL");
				}
			}
		}
		else
		{
			cout << "Attribute already in table" << endl;
		}
	}

	void Table::removeAttribute(string attributeName)
	{
		bool attributeExists = false;
		int attributeIndex;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName == attributeDefinitions[i].name)
				{
					attributeExists = true;
					attributeIndex = i;
				}
			}
		}
		if (attributeExists)
		{
			attributeDefinitions.erase(attributeDefinitions.begin() + attributeIndex);
			if (!rows.empty())
			{
				for (int i = 0; i < rows.size(); i++)
				{
					rows[i].attributes.erase(rows[i].attributes.begin() + attributeIndex);
				}
			}
		}
	}

	void Table::setKey(string key)
	{
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (key == attributeDefinitions[i].name)
				{
					attributeDefinitions[i].isKey = true;
				}
			}
		}
	}

	void Table::renameAttribute(string attributeName, string newAttributeName)
	{
		bool attributeExists = false;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName == attributeDefinitions[i].name)
				{
					attributeExists = true;
					attributeDefinitions[i].name = newAttributeName;
				}
			}
		}
		if (!attributeExists)
		{
			cout << "Attribute does not currently exist" << endl;
		}
	}

/*	void Table::insertRecord(Record input)
	{
		rows.push_back(input);
	}*/

	vector<Attribute> Table::getAttributes()
	{
		return attributeDefinitions;
	}

	int Table::getSize()
	{
		return (int)rows.size();
	}

	Table Table::crossJoin(Table tableA, Table tableB)
	{
		Table joinedTable;
		joinedTable.attributeDefinitions = tableA.attributeDefinitions;
		joinedTable.attributeDefinitions.insert(joinedTable.attributeDefinitions.end(), tableB.attributeDefinitions.begin(), tableB.attributeDefinitions.end());
		int aSize = tableA.getSize();
		int bSize = tableB.getSize();
		for (int i = 0; i < bSize; i++)
		{
			for (int j = 0; j < aSize; j++)
			{
				joinedTable.insertRecord(tableA.rows[j]);
				int currentRow = (i*bSize) + j;
				for (int k = 0; k < tableB.rows[i].attributes.size(); k++)
				{
					joinedTable.rows[currentRow].attributes.push_back(tableB.rows[i].attributes[k]);
				}
			}
		}

		return joinedTable;
	}

	int Table::countAttribute(string attributeName)
	{
		int numNotNull = 0;
		if (!rows.empty())
		{
			bool attributeExists = false;
			int attributeIndex;
			if (!attributeDefinitions.empty())
			{
				for (int i = 0; i < attributeDefinitions.size(); i++)
				{
					if (attributeName == attributeDefinitions[i].name)
					{
						if (attributeExists)
						{
							cout << "Duplicate index; returning 0" << endl;
							return 0;
						}
						attributeExists = true;
						attributeIndex = i;
					}
				}
			}
			if (attributeExists)
			{
				for (int i = 0; i < rows.size(); i++)
				{
					if (rows[i].attributes[attributeIndex] != "NULL")
					{
						numNotNull++;
					}
				}
			}
			else
			{
				cout << "Attribute does not currently exist" << endl;
			}
		}
		return numNotNull;
	}

	// default isUnique is false
	void Table::setUnique(string attributeName) {
		int i;
		for (i = 0; i < attributeDefinitions.size(); ++i) {
			if (attributeName.compare(attributeDefinitions[i].name) == 0) {
				if (checkUnique(attributeName)) {
					attributeDefinitions[i].isUnique = true;
				}
				break;
			}
		}
		if (i == attributeDefinitions.size()) {
			cout << "Attribute name not found" << endl;
		}
	}

	// checks if there are duplicate entries in an attribute column
	bool Table::checkUnique(string attributeName) {

		vector<string> recordEntries;

		// create a vector of record entries for the given attribute
		if (!attributeDefinitions.empty()) {
			for (int i = 0; i < attributeDefinitions.size(); ++i) {
				Record currRecord = rows[i];
				string currEntry = currRecord[i];
				recordEntries.push_back(currEntry);
			}

			// check if the vector has all unique values. unique() removes duplicate values. if nothing removed from vector, return is the same as vector.end()
			sort(recordEntries.begin(), recordEntries.end());
			auto j = unique(recordEntries.begin(), recordEntries.end());
			bool wasUnique = (j == recordEntries.end());
			return wasUnique;
		}
		else cout << "Attribute entries not unique" << endl;
		return 0;
	}

	string Table::min(string attributeName)
	{
		bool hasNonNullEntries = false;
		if (!rows.empty())
		{
			bool attributeExists = false;
			int attributeIndex;
			if (!attributeDefinitions.empty())
			{
				for (int i = 0; i < attributeDefinitions.size(); i++)
				{
					if (attributeName == attributeDefinitions[i].name)
					{
						if (attributeExists)
						{
							cout << "Duplicate index; returning 0" << endl;
							return 0;
						}
						attributeExists = true;
						attributeIndex = i;
					}
				}
			}
			if (attributeExists)
			{
				string attributeType = attributeDefinitions[attributeIndex].type;
				if (attributeType == "int")
				{
					int currentMin = 10000000;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stoi(currentValue) < currentMin)
							{
								currentMin = stoi(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMin));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else if (attributeType == "float")
				{
					float currentMin = 10000000;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stof(currentValue) < currentMin)
							{
								currentMin = stof(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMin));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else
				{
					cout << "Attribute does not contain numerical data" << endl;
					return "NULL";
				}
			}
			else
			{
				cout << "Attribute does not currently exist" << endl;
			}
		}
		else
		{
			return "NULL";
		}
		return "NULL";
	}

	string Table::max(string attributeName)
	{
		bool hasNonNullEntries = false;
		if (!rows.empty())
		{
			bool attributeExists = false;
			int attributeIndex;
			if (!attributeDefinitions.empty())
			{
				for (int i = 0; i < attributeDefinitions.size(); i++)
				{
					if (attributeName == attributeDefinitions[i].name)
					{
						if (attributeExists)
						{
							cout << "Duplicate index; returning 0" << endl;
							return 0;
						}
						attributeExists = true;
						attributeIndex = i;
					}
				}
			}
			if (attributeExists)
			{
				string attributeType = attributeDefinitions[attributeIndex].type;
				if (attributeType == "int")
				{
					int currentMax = -10000000;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stoi(currentValue) > currentMax)
							{
								currentMax = stoi(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMax));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else if (attributeType == "float")
				{
					float currentMax = -10000000;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stof(currentValue) > currentMax)
							{
								currentMax = stof(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMax));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else
				{
					cout << "Attribute does not contain numerical data" << endl;
					return "NULL";
				}
			}
			else
			{
				cout << "Attribute does not currently exist" << endl;
			}
		}
		else
		{
			return "NULL";
		}
		return "NULL";
	}