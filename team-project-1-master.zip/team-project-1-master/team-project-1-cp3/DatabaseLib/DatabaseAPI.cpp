#include "DatabaseAPI.h"
#include <string>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <boost/spirit/home/x3.hpp>
#include <boost/config/warning_disable.hpp>
namespace x3 = boost::spirit::x3;
using namespace DatabaseAPI; 
/*struct compareTables
{
	inline bool operator() (const Table& lhs, const Table& rhs)
	{
		return lhs.howdy < rhs.howdy;
	}
};*/
static bool compareTables(Table a, Table b)
{
	int compareInt = a.howdy.compare(b.howdy);
	if (compareInt == -1)
		return true;
}
	Database::Database() {
		tableObjects = vector<Table>();
		tableNames = vector<string>();
		std::cout << "Hello\n";
	}
	void Database::addTable(Table object, string tableName) {
		tableObjects.push_back(object);
		if (object.howdy != tableName)
			object.howdy = tableName;
		tableNames.push_back(tableName);
		sort(tableObjects.begin(), tableObjects.end(), compareTables);
		sort(tableNames.begin(), tableNames.end());
		
	}
	void Database::removeTable(string tableName){
		auto it = find_if(tableObjects.begin(), tableObjects.end(), [&tableName](const Table& obj) {return obj.howdy == tableName; });
		if (it != tableObjects.end())
		{
			tableObjects.erase(it);
		}
		//auto it2 = binary_search
		auto it2 = find(tableNames.begin(), tableNames.end(), tableName);
		if (it2 != tableNames.end())
		{
			tableNames.erase(it2);
		}
	}
	vector<string> Database::listTables()
	{
		return tableNames;
	}
	vector<Table> Database::getTables() {
		return tableObjects;
	}
	void printAttributeColumn(vector<Attribute> allA, ostream& os)
	{
		os << "NEWATTCOL";
		for(unsigned int i = 0; i < allA.size(); ++i)
		{
			os << allA[i].name << " ";
		}
		for (unsigned int i = 0; i < allA.size(); ++i)
		{
			os << allA[i].type << " ";
		}
		for (unsigned int i = 0; i < allA.size(); ++i)
		{
			os << allA[i].isUnique << " ";
		}
		os << "\n";
	}
	void printRecordToFile(Record r, ostream& os)
	{
		os << "NEWRECORD" << "\n";
		for (int i = 0; i < r.getSize(); ++i)
		{
			os << r.attributes[i] << " ";
		}
		os << "\n";
	}
	void printTableToFile(Table t, ostream& os)
	{
		os << "NEWTABLE" << "\n";
		os << t.howdy << "\n";
		printAttributeColumn(t.getAttributes(), os);
		for (int i = 0; i < t.getSize(); ++i)
		{
			printRecordToFile(t.rows[i], os);
		}
		os << "ENDTABLE" << "\n";
	}
	
	void operator<<(ostream& os, const Database& en){
		
		for(unsigned int i = 0; i < en.tableObjects.size(); ++i)
			printTableToFile(en.tableObjects[i], os);

	}
	/*ifstream& operator>>(ifstream& is, Database& en) {
		
	}*/
	
	
	void Database::saveDatabase(string fileName)
	{
		ofstream myFile;
		myFile.open(fileName);
		myFile << this;

	}


	
		
		using x3::_attr;

		struct print_action
		{
			template <typename Context>
			void operator()(Context const& ctx) const
			{
				std::cout << _attr(ctx) << std::endl;
			}
		};
	

	
	void Database::loadDatabase(string fileName)
	{
		Database db = Database();
		Table t = Table();
		Record r = Record();
		bool isTable;
		bool isRow;
		bool isAttributeColumn;
		bool passed;
		int caseD = 0;
		ifstream myFile;
		myFile.open(fileName);
		
		while (!myFile.eof())
		{
			string temp;
			getline(myFile, temp);
			if (temp.compare("NEWTABLE")) {
				t = Table();
				isTable = true;
				isRow = false;
				isAttributeColumn = false;
				passed = true;
				caseD = 1;
			}
			else if (temp.compare("NEWATTCOL"))
			{
				isTable = false;
				isRow = false;
				isAttributeColumn = true;
				passed = true;
				caseD = 2;
			}
			else if (temp.compare("NEWRECORD"))
			{
				isTable = false;
				isRow = true;
				isAttributeColumn = false;
				passed = true;
				caseD = 3;
			}
			else if (temp.compare("ENDTABLE"))
			{
				passed = true;
				caseD = 3;
			}
		}
		if (passed)
		{
			string line;
			string token;
			getline(myFile, line);
			stringstream linestream(line);
			//vector<string>
				switch (caseD) {
				case 1:
				{
					//NEW TABLE
					string name;
					linestream << name;
					caseD = 0;
					passed = false;
					break;
				}
				case 2:
				{
					//ATTRIBUTE COLUMN
					string name;
					vector<Attribute> cols;
					while (linestream << name)
					{
						Attribute a = Attribute();
						a.name = name;
						cols.push_back(a);
					}
					getline(myFile, line);
					linestream = stringstream(line);
					int count = 0;
					while (linestream << name)
					{
						cols[count].setType(name);
						count++;
					}
					
					getline(myFile, line);
					linestream = stringstream(line);
					count = 0;
					bool isUniq = 0;
					while (linestream << isUniq)
					{
						cols[count].isUnique = isUniq;
					}
					caseD = 0;
					passed = false;
					break;
				}
				case 3:
				{
					//RECORD
					vector<string> record;
					getline(myFile, line);
					linestream = stringstream(line);
					string att;
					while (linestream << att)
					{
						record.push_back(att);
					}
					t.insertRecord(record);
					caseD = 0;
					passed = false;
					break;
				}
				case 4:
				{
					//ENDTABLE

					
				}
				default:
				{

					caseD = 0;
					passed = false;
					break;
				}
				}
		}
		
		/*
			//istream(temp);
			using boost::spirit::x3::int_;
			using boost::spirit::x3::parse;
			using x3::lit;
			//using client::print_action;

			{ // example using function object

				char const *first = "{43}", *last = first + std::strlen(first);
				parse(first, last, '{' >> int_[print_action()] >> '}');
			}

			{ // example using C++14 lambda

				using boost::spirit::x3::_attr;
				char const *first = "{44}", *last = first + std::strlen(first);
				auto f = [](auto& ctx) { std::cout << _attr(ctx) << std::endl; };
				parse(first, last, '{' >> int_[f] >> '}');
			}

			*/
		}
	/*void Database::loadDatabase(string fileName)
	{
		Database a = Database();
		Table t = Table();
		Record r = Record();
		bool isTable;
		bool isRow;
		bool isAttributeColumn;
		string line;
		ifstream myFile;
		myFile.open(fileName);
		while (getline(myFile, line))
		{
			std::stringstream   linestream(line);
			std::string         data;
			

			// If you have truly tab delimited data use getline() with third parameter.
			// If your data is just white space separated data
			// then the operator >> will do (it reads a space separated word into a string).
			//std::getline(linestream, data, '\t');  // read up-to the first tab (discard tab).

			// Read the integers using the operator >>
			namespace x3 = boost::spirit::x3;
			namespace ascii = boost::spirit::x3::ascii;
			using x3::int_;
			using x3::lit;
			using x3::double_;
			using x3::lexeme;
			using ascii::char_;
			auto iter = line.begin();
			auto end_iter = line.end();
			Record r;
			//x3::parse(iter, end_iter, +(+char_(("a-z"))) >> ' ' >> (+char_("a-z")));
			vector<string> result;
			
			

		}
	}*/
	
	


		Table::Table() {
			vector<Attribute> temp = vector<Attribute>();
			vector<Record> temp2 = vector<Record>();
			attributeDefinitions = temp;
			rows = temp2;
			std::cout << "hello\n";
		}
		
		void Table::insertRecord(Record input)
		{
			cout << "hello\n";
		}

	// default constructor
	Record::Record() {
		attributes = vector<string>();
	}

	// constructor with arguments
	Record::Record(vector<string> orderedSet) {
		attributes = orderedSet;
	}

	// return number of columns in a record
	int Record::getSize() {
		int recordSize = attributes.size();
		return recordSize;
	}

	string Record::operator[] (int index) {
		return attributes[index];
	}

	Attribute::Attribute() {
		name = "";
		type = "";
		isKey = false;
		isUnique = false;
		std::cout << "hello\n";
	}
	void Attribute::setType(string a) {
		std::cout << "hello\n";
	}


	vector<Record>::iterator Table::getRecord(int i)
	{
		vector<Record>::iterator it = rows.begin();
		advance(it, i);
		return it;
	}
/*	Table::Table() {
		vector<Attribute> temp = vector<Attribute>();
		vector<Record> temp2 = vector<Record>();
		attributeDefinitions = temp;
		rows = temp2;
		std::cout << "hello\n";
	}*/
	

	
/*	Record::Record() {
		attributes = vector<string>();

		std::cout << "hello\n";
	}
	int Record::getSize() {
		std::cout << "hello\n";
		return 0;
	}
	Attribute::Attribute() {
		name = "";
		type = "";
		isKey = false;
		isUnique = false;
		std::cout << "hello\n";
	}
	void Attribute::setType(string a) {
		std::cout << "hello\n";
	}

	Table::Table()
	{
	}
	*/
	Table::Table(vector<Attribute> attributes)
	{
		attributeDefinitions = attributes;
	}

	void Table::addAttribute(string attributeName)
	{
		bool addAttributeToTable = true;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName == attributeDefinitions[i].name)
				{
					addAttributeToTable = false;
				}
			}
		}
		if (addAttributeToTable)
		{
			Attribute newAttribute=Attribute();
			newAttribute.name = attributeName;
			attributeDefinitions.push_back(newAttribute);
			if (!rows.empty())
			{
				for (int i = 0; i < rows.size(); i++)
				{
					rows[i].attributes.push_back("NULL");
				}
			}
		}
		else
		{
			cout << "Attribute already in table" << endl;
		}
	}

	void Table::addAttribute(Attribute attributeName)
	{
		bool addAttributeToTable = true;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName.name == attributeDefinitions[i].name)
				{
					addAttributeToTable = false;
				}
			}
		}
		if (addAttributeToTable)
		{
			attributeDefinitions.push_back(attributeName);
			if (!rows.empty())
			{
				for (int i = 0; i < rows.size(); i++)
				{
					rows[i].attributes.push_back("NULL");
				}
			}
		}
		else
		{
			cout << "Attribute already in table" << endl;
		}
	}

	void Table::removeAttribute(string attributeName)
	{
		bool attributeExists = false;
		int attributeIndex;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName == attributeDefinitions[i].name)
				{
					attributeExists = true;
					attributeIndex = i;
				}
			}
		}
		if (attributeExists)
		{
			attributeDefinitions.erase(attributeDefinitions.begin() + attributeIndex);
			if (!rows.empty())
			{
				for (int i = 0; i < rows.size(); i++)
				{
					rows[i].attributes.erase(rows[i].attributes.begin() + i);
				}
			}
		}
	}

	void Table::setKey(string key)
	{
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (key == attributeDefinitions[i].name)
				{
					attributeDefinitions[i].isKey = true;
				}
			}
		}
	}

	void Table::renameAttribute(string attributeName, string newAttributeName)
	{
		bool attributeExists = false;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName == attributeDefinitions[i].name)
				{
					attributeExists = true;
					attributeDefinitions[i].name = newAttributeName;
				}
			}
		}
		if (!attributeExists)
		{
			cout << "Attribute does not currently exist" << endl;
		}
	}

/*	void Table::insertRecord(Record input)
	{
		rows.push_back(input);
	}*/

	vector<Attribute> Table::getAttributes()
	{
		return attributeDefinitions;
	}

	int Table::getSize()
	{
		return (int)rows.size();
	}

	Table Table::crossJoin(Table tableA, Table tableB)
	{
		Table joinedTable;
		joinedTable.attributeDefinitions = tableA.attributeDefinitions;
		joinedTable.attributeDefinitions.insert(joinedTable.attributeDefinitions.end(), tableB.attributeDefinitions.begin(), tableB.attributeDefinitions.end());
		int aSize = tableA.getSize();
		int bSize = tableB.getSize();
		for (int i = 0; i < bSize; i++)
		{
			for (int j = 0; j < aSize; j++)
			{
				joinedTable.insertRecord(tableA.rows[j]);
				int currentRow = (i*bSize) + j;
				for (int k = 0; k < tableB.rows[i].attributes.size(); k++)
				{
					joinedTable.rows[currentRow].attributes.push_back(tableB.rows[i].attributes[k]);
				}
			}
		}

		return joinedTable;
	}

	int Table::countAttribute(string attributeName)
	{
		int numNotNull = 0;
		if (!rows.empty())
		{
			bool attributeExists = false;
			int attributeIndex;
			if (!attributeDefinitions.empty())
			{
				for (int i = 0; i < attributeDefinitions.size(); i++)
				{
					if (attributeName == attributeDefinitions[i].name)
					{
						if (attributeExists)
						{
							cout << "Duplicate index; returning 0" << endl;
							return 0;
						}
						attributeExists = true;
						attributeIndex = i;
					}
				}
			}
			if (attributeExists)
			{
				for (int i = 0; i < rows.size(); i++)
				{
					if (rows[i].attributes[attributeIndex] != "NULL")
					{
						numNotNull++;
					}
				}
			}
			else
			{
				cout << "Attribute does not currently exist" << endl;
			}
		}
		return numNotNull;
	}

	// default isUnique is false
	void Table::setUnique(string attributeName) {
		int i;
		for (i = 0; i < attributeDefinitions.size(); ++i) {
			if (attributeName.compare(attributeDefinitions[i].name) == 0) {
				if (checkUnique(attributeName)) {
					attributeDefinitions[i].isUnique = true;
				}
				break;
			}
		}
		if (i == attributeDefinitions.size()) {
			cout << "Attribute name not found" << endl;
		}
	}

	// checks if there are duplicate entries in an attribute column
	bool Table::checkUnique(string attributeName) {

		vector<string> recordEntries;

		// create a vector of record entries for the given attribute
		if (!attributeDefinitions.empty()) {
			for (int i = 0; i < attributeDefinitions.size(); ++i) {
				Record currRecord = rows[i];
				string currEntry = currRecord[i];
				recordEntries.push_back(currEntry);
			}

			// check if the vector has all unique values. unique() removes duplicate values. if nothing removed from vector, return is the same as vector.end()
			sort(recordEntries.begin(), recordEntries.end());
			auto j = unique(recordEntries.begin(), recordEntries.end());
			bool wasUnique = (j == recordEntries.end());
			return wasUnique;
		}
		else cout << "Attribute entries not unique" << endl;
		return 0;
	}

	string Table::min(string attributeName)
	{
		bool hasNonNullEntries = false;
		if (!rows.empty())
		{
			bool attributeExists = false;
			int attributeIndex;
			if (!attributeDefinitions.empty())
			{
				for (int i = 0; i < attributeDefinitions.size(); i++)
				{
					if (attributeName == attributeDefinitions[i].name)
					{
						if (attributeExists)
						{
							cout << "Duplicate index; returning 0" << endl;
							return 0;
						}
						attributeExists = true;
						attributeIndex = i;
					}
				}
			}
			if (attributeExists)
			{
				string attributeType = attributeDefinitions[attributeIndex].type;
				if (attributeType == "int")
				{
					int currentMin = 10000000;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stoi(currentValue) < currentMin)
							{
								currentMin = stoi(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMin));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else if (attributeType == "float")
				{
					float currentMin = 10000000;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stof(currentValue) < currentMin)
							{
								currentMin = stof(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMin));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else
				{
					cout << "Attribute does not contain numerical data" << endl;
					return "NULL";
				}
			}
			else
			{
				cout << "Attribute does not currently exist" << endl;
			}
		}
		else
		{
			return "NULL";
		}
	}

	string Table::max(string attributeName)
	{
		bool hasNonNullEntries = false;
		if (!rows.empty())
		{
			bool attributeExists = false;
			int attributeIndex;
			if (!attributeDefinitions.empty())
			{
				for (int i = 0; i < attributeDefinitions.size(); i++)
				{
					if (attributeName == attributeDefinitions[i].name)
					{
						if (attributeExists)
						{
							cout << "Duplicate index; returning 0" << endl;
							return 0;
						}
						attributeExists = true;
						attributeIndex = i;
					}
				}
			}
			if (attributeExists)
			{
				string attributeType = attributeDefinitions[attributeIndex].type;
				if (attributeType == "int")
				{
					int currentMax = -10000000;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stoi(currentValue) > currentMax)
							{
								currentMax = stoi(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMax));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else if (attributeType == "float")
				{
					float currentMax = -10000000;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stof(currentValue) > currentMax)
							{
								currentMax = stof(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMax));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else
				{
					cout << "Attribute does not contain numerical data" << endl;
					return "NULL";
				}
			}
			else
			{
				cout << "Attribute does not currently exist" << endl;
			}
		}
		else
		{
			return "NULL";
		}
	}
