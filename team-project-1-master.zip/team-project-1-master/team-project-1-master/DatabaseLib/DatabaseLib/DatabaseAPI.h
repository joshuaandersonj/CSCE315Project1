#include <stdio.h>
#include <string>
#include <vector>
#include <iostream>
#include <iterator>
#include <vector>
using namespace std;
namespace DatabaseAPI {
	class Database {
	public:
		vector<Table> tableObjects;
		Database();
		void addTable(Table object,string tableName);
		void removeTable(string tableName);
		void saveDatabase(string fileMame);
		void loadDatabase(string fileName);

		string listTables();
		vector<Table> getTables();
		//query function
		Table query(string select, string from, string where);
		//delete command
		void removeTable(string select, string from, string where);
		//update/modify command, set attribute could be in the attribute class
		void updateTable(string tableName, string setAttribute)
		
	};

	class Table {
		vector<Attribute> attributeDefinitions;
		vector<Record> rows;
		Table();
		Table(vector<Attribute>);
		void addAttribute(string attributeName);
		void removeTable(string attributeName);
		void insertRecord(Record input);
		vector<Attribute> getAttributes();
		int getSize();
		vector<string>::iterator getRecord(string key);
		void setKey(string key);
		void renameAttribute(string attributeName, string newAttributeName);
		void setKey(vector<string> key);
		Table crossJoin(Table tableA, Table tableB);
		Table naturaljoin(Table tableA, Table tableB);
		int countAttribute(string attributeName);
		string min(string a);
		string max(string a);

	};
	class Record {
		vector<string> attributes;
		Record();
		Record(vector<string> orderedSet);
		int getSize();
		string& operator [] (string index);
		
	};
	class Attribute {
		string name;
		string value;
		string type;
	};
	
	};
