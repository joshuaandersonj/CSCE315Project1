#include "DatabaseAPI.h"
namespace DatabaseAPI {
	
		Database::Database() {
			
			std::cout << "Hello";
		}
	void addTable() {
		std::cout << "hello";
		}

	


		Table::Table() {
			
			std::cout << "hello";
		}
	Record::Record() {
			
			std::cout << "hello";
		}
	
}