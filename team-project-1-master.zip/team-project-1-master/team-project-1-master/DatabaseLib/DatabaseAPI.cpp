#include "DatabaseAPI.h"
#include <string>
#include <algorithm>
using namespace DatabaseAPI;

bool compareTables(const Table* lhs, const Table* rhs)
{
	return lhs->howdy < rhs->howdy;
}

	Database::Database() {
		tableObjects = vector<Table>();
		tableNames = vector<string>();
		std::cout << "Hello\n";
	}
	void Database::addTable(Table object, string tableName) {
		tableObjects.push_back(object);
		if (object.howdy != tableName)
			object.howdy = tableName;
		tableNames.push_back(tableName);
		sort(tableObjects.begin(), tableObjects.end(), compareTables);
		sort(tableNames.begin(), tableNames.end());

	}
	void Database::removeTable(string tableName){
		auto it = find_if(tableObjects.begin(), tableObjects.end(), [&tableName](const Table& obj) {return obj.howdy == tableName; });
		if (it != tableObjects.end())
		{
			tableObjects.erase(it);
		}
		//auto it2 = binary_search
		auto it2 = search(tableNames.begin(), tableNames.end(), tableName);
		if (it2 != tableNames.end())
		{
			tableNames.erase(it2);
		}
	}
	vector<string> Database::listTables()
	{
		return tableNames;
	}
	vector<Table> Database::getTables() {
		return tableObjects;
	}
	ostream& operator<<(ostream& os, const Database& en){

		for(unsigned int i = 0; i < en.tableObjects.size(); ++i)
			printTableToFile(en.tableObjects[i], os);

	}
	istream& operator>>(istream& is, Database& en) {

	}
	void printTableToFile(Table t, ostream& os)
	{
		printAttributeColumn(t.getAttributes(), os);
		for (unsigned int i = 0; i < t.getSize(); ++i)
		{
			printRecordToFile(t.rows[i], os);
		}
	}
	void printRecordToFile(Record r, ostream& os)
	{

		for (unsigned int i = 0; i < r.getSize(); ++i)
		{
			os << r.attributes[i];
		}
		os << "\n";
	}
	void printAttributeColumn(vector<Attribute> allA, ostream& os)
	{
		for (unsigned int i = 0; i < allA.size(); ++i)
		{
			os << allA[i].name;
		}
		os << "\n";
	}
	void Database::saveDatabase(string fileName)
	{

	}


		Table::Table() {
			vector<Attribute> temp = vector<Attribute>();
			vector<Record> temp2 = vector<Record>();
			attributeDefinitions = temp;
			rows = temp2;
			std::cout << "hello\n";
		}

		void Table::insertRecord(Record input)
		{
			cout << "hello\n";
		}

	Attribute::Attribute() {
		name = "";
		type = "string";
		isKey = false;
		isUnique = false;
		std::cout << "hello\n";
	}
	void Attribute::setType(string a) {
		std::cout << "hello\n";
	}


	vector<Record>::iterator Table::getRecord(int i)
	{
		vector<Record>::iterator it = rows.begin();
		advance(it, i);
		return it;
	}
	Table::Table() {
		vector<Attribute> temp = vector<Attribute>();
		vector<Record> temp2 = vector<Record>();
		attributeDefinitions = temp;
		rows = temp2;
		std::cout << "hello\n";
	}
	void Database::addTable(Table object, string tableName) {
		std::cout << "hello\n";
	}

	void Table::insertRecord(Record input)
	{
		cout << "hello\n";
	}

	// default constructor
	Record::Record() {
	  Record r1 = vector<string> entries;
	  entries.push_back("");
	}

	// constructor with arguments
	Record::Record(vector<string> orderedSet) {
	  Record r1 = orderedSet;
	}

	// return number of columns in record
	int Record::getRecordSize() {
	  int recordSize = attributes.size();
	  return recordSize;
	}

	// update API for new arguments
	// take attribute name as iterator and return corresponding record entry
	Record::operator[] (string const* a) {
	  for (unsigned int i = 0; i < attributes.size(); ++i) {
	    if (a == attributes[i]) {
	      return orderedSet.at(i);
	    }
	    else cout << "Attribute name not found" << endl;
	}

	Attribute::Attribute() {
		name = "";
		type = "";
		isKey = false;
		isUnique = false;
		std::cout << "hello\n";
	}
	void Attribute::setType(string a) {
		std::cout << "hello\n";
	}

	Table::Table()
	{
	}

	Table::Table(vector<Attribute> attributes)
	{
		attributeDefinitions = attributes;
	}

	void Table::addAttribute(string attributeName)
	{
		bool addAttributeToTable = true;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName == attributeDefinitions[i].name)
				{
					addAttributeToTable = false;
				}
			}
		}
		if (addAttributeToTable)
		{
			Attribute newAttribute=Attribute();
			newAttribute.name = attributeName;
			attributeDefinitions.push_back(newAttribute);
			if (!rows.empty)
			{
				for (int i = 0; i < rows.size(); i++)
				{
					rows[i].attributes.push_back("NULL");
				}
			}
		}
		else
		{
			cout << "Attribute already in table" << endl;
		}
	}

	void Table::addAttribute(Attribute attributeName)
	{
		bool addAttributeToTable = true;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName.name == attributeDefinitions[i].name)
				{
					addAttributeToTable = false;
				}
			}
		}
		if (addAttributeToTable)
		{
			attributeDefinitions.push_back(attributeName);
			if (!rows.empty)
			{
				for (int i = 0; i < rows.size(); i++)
				{
					rows[i].attributes.push_back("NULL");
				}
			}
		}
		else
		{
			cout << "Attribute already in table" << endl;
		}
	}

	void Table::removeAttribute(string attributeName)
	{
		bool attributeExists = false;
		int attributeIndex;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName == attributeDefinitions[i].name)
				{
					attributeExists = true;
					attributeIndex = i;
				}
			}
		}
		if (attributeExists)
		{
			attributeDefinitions.erase(attributeDefinitions.begin() + attributeIndex);
			if (!rows.empty)
			{
				for (int i = 0; i < rows.size(); i++)
				{
					rows[i].attributes.erase(rows[i].attributes.begin() + i);
				}
			}
		}
	}

	void Table::setKey(string key)
	{
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (key == attributeDefinitions[i].name)
				{
					attributeDefinitions[i].isKey = true;
				}
			}
		}
	}

	// uses overloaded subscript operator in record class to get every entry for a given attribute
	// default isUnique is false
	void Table::setUnique(string attributeName) {
		if (!checkUnique(attributeName)) {
			cout << "Duplicate entries exist. Cannot setUnique() for this attribute" << endl;
		}
		else {
			// set attribute's isUnique to true
			attributeName.isUnique == 1;
		}
	}

	// checks if there are duplicate entries in an attribute column
	bool Table::checkUnique(string attributeName) {
		vector<string> recordEntries;

		// create a vector of record entries for the given attribute
		if (!attributeDefinitions.empty()) {
			for (int i = 0; i < table.getSize(); ++i) {
				string curr = record[attributeName];
				recordEntries.push_back(curr);
			}

			// check if the vector has all unique values. unique() removes duplicate values. if nothing removed from vector, return is the same as vector.end()
			sort(recordEntries.begin(), recordEntries.end());
			auto j = unique(recordEntries.begin(), recordEntries.end());
			bool wasUnique = (j == recordEntries.end());
			return wasUnique;

		}
		else cout << "Attributes are empty" << endl;
		return 0;
	}

	void Table::renameAttribute(string attributeName, string newAttributeName)
	{
		bool attributeExists = false;
		if (!attributeDefinitions.empty())
		{
			for (int i = 0; i < attributeDefinitions.size(); i++)
			{
				if (attributeName == attributeDefinitions[i].name)
				{
					attributeExists = true;
					attributeDefinitions[i].name = newAttributeName;
				}
			}
		}
		if (!attributeExists)
		{
			cout << "Attribute does not currently exist" << endl;
		}
	}

void Table::insertRecord(Record input)
{
	if (input.attributes.size() > attributeDefinitions.size())
	{
		input.attributes.pop_back(input.attributes.size() - attributeDefinitions.size());
	}
	else if (input.attributes.size() < attributeDefinitions.size())
	{
		for (int i = input.attributes.size(); i < attributeDefinitions.size(); i++)
		{
			input.attributes.push_back("NULL");
		}
	}
	if (!rows.empty())
	{
		bool uniqueSatisfied = true;
		for (int i = 0; i < attributeDefinitions.size(); i++)
		{
			if (attributeDefinitions[i].isUnique == true) 
			{
				for (int j = 0; j < rows.size(); j++)
				{
					if (input.attributes[i] == size[j].attributes[i])
					{
						uniqueSatisfied = false;
					}
				}
			}
		}
		if (uniqueSatisfied)
		{
			rows.push_back(input);
		}
		else
		{
			cout << "Uniqueness not satisfied; record not pushed" << endl;
		}
	}
	else
	{
		rows.push_back(input);
	}
}

	vector<Attribute> Table::getAttributes()
	{
		return attributeDefinitions;
	}

	int Table::getSize()
	{
		return rows.size();
	}

	Table Table::crossJoin(Table tableA, Table tableB)
	{
		Table joinedTable;
		joinedTable.attributeDefinitions = tableA.attributeDefinitions;
		joinedTable.attributeDefinitions.insert(joinedTable.attributeDefinitions.end(), tableB.attributeDefinitions.begin(), tableB.attributeDefinitions.end());
		int aSize = tableA.getSize();
		int bSize = tableB.getSize();
		for (int i = 0; i < bSize; i++)
		{
			for (int j = 0; j < aSize; j++)
			{
				joinedTable.insertRecord(tableA.rows[j]);
				int currentRow = (i*bSize) + j;
				for (int k = 0; k < tableB.rows[i].attributes.size(); k++)
				{
					joinedTable.rows[currentRow].attributes.push_back(tableB.rows[i].attributes[k]);
				}
			}
		}
		return joinedTable;
	}
		
Table Table::naturaljoin(Table tableA, Table tableB)
{
	Table joinedTable;
	vector<Attribute> aAttributes = tableA.getAttributes();
	vector<Attribute> bAttributes = tableB.getAttributes();
	vector<string> keyAttributeNames;
	vector<int> matchIndecies;
	for (int i = 0; i < bAttributes.size(); i++)
	{
		if (bAttribures[i].isKey == true)
		{
			keyAttributeNames.push_back(bAttributes[i].name);
			matchIndecies.push_back(i);
		}
	}
	if (keyAttributeNames.empty())
	{
		cout << "Second table has no key attributes" << endl;
		return joinedTable;
	}
	else
	{
		bool hasMatchingAttributes = false;
		vector<string> matchingAttributes;
		vector<int> aMatchingIndices;
		for (int i = 0; i < aAttributes.size(); i++)
		{
			for (int j = 0; j < keyAttributeNames.size(); j++)
			{
				if (aAttributes[i].name == keyAttributeNames[j])
				{
					hasMatchingAttributes = true;
					matchingAttributes.push_back(keyAttributeNames[j]);
					aMatchingIndices.push_back(i);
				}
			}
		}
		if (hasMatchingAttributes)
		{
			joinedTable = tableA;
			vector<int> nonMatchingIndices;
			vector<int> bMatchingIndices;
			for (int i = 0; i < bAttributes.size(); i++)
			{
				bool noMatch = true;
				for (int j = 0; j < matchingAttributes.size(); j++)
				{
					if (bAttributes[i].name == matchingAttributes[j])
					{
						noMatch = false;
						bMatchingIndices.push_back(i);
					}
				}
				if (noMatch)
				{
					joinedTable.addAttribute(bAttributes[i].name);
					nonMatchingIndices.push_back(i);
				}
			}
			for (int i = 0; i < joinedTable.getSize(); i++)
			{
				for (j = 0; j < tableB.getSize(); j++)
				{
					bool correspondingRow = true;
					for (int k = 0; k < aMatchingIndices.size(), k+)
					{
						for (int l = 0; l < bMatchingIndices.size(); l++)
						{
							if(joinedTable.rows[i].attributes[aMatchingIndices[k]] != tableB.rows[j].attributes[bMatchingIndicies[l]])
							{
								correspondingRow = false;
							}
						}
					}
					if (correspondingRow)
					{
						for (int m = 0; m < bAttributes.size(); m++)
						{
							bool notMatchingAttribute = true;
							for (int n = 0; n < bMatchingIndices.size(); n++)
							{
								if (m = bMatchingIndices[n])
								{
									notMatchingAttribute = false;
								}
							}
							if (notMatchingAttribute)
							{
								joinedTable.rows[i].attributes.push_back(tableB.rows[j].attributes[m]);
							}
						}
					}
				}
			}
			return joinedTable;
		}
		else
		{
			cout << "First table has no attributes that match key attributes of the second table" << endl;
			return joinedTable;
		}
	}
}
		
	int Table::countAttribute(string attributeName)
	{
		int numNotNull = 0;
		if (!rows.empty())
		{
			bool attributeExists = false;
			int attributeIndex;
			if (!attributeDefinitions.empty())
			{
				for (int i = 0; i < attributeDefinitions.size(); i++)
				{
					if (attributeName == attributeDefinitions[i].name)
					{
						if (attributeExists)
						{
							cout << "Duplicate index; returning 0" << endl;
							return 0;
						}
						attributeExists = true;
						attributeIndex = i;
					}
				}
			}
			if (attributeExists)
			{
				for (int i = 0; i < rows.size(); i++)
				{
					if (rows[i].attributes[attributeIndex] != "NULL")
					{
						numNotNull++;
					}
				}
			}
			else
			{
				cout << "Attribute does not currently exist" << endl;
			}
		}
		return numNotNull;
	}

	string Table::min(string attributeName)
	{
		bool hasNonNullEntries = false;
		if (!rows.empty())
		{
			bool attributeExists = false;
			int attributeIndex;
			if (!attributeDefinitions.empty())
			{
				for (int i = 0; i < attributeDefinitions.size(); i++)
				{
					if (attributeName == attributeDefinitions[i].name)
					{
						if (attributeExists)
						{
							cout << "Duplicate index; returning 0" << endl;
							return 0;
						}
						attributeExists = true;
						attributeIndex = i;
					}
				}
			}
			if (attributeExists)
			{
				string attributeType = attributeDefinitions[attributeIndex].type;
				if (attributeType == "int")
				{
					int currentMin = INT_MAX;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stoi(currentValue) < currentMin)
							{
								currentMin = stoi(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMin));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else if (attributeType == "float")
				{
					float currentMin = INT_MAX;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stof(currentValue) < currentMin)
							{
								currentMin = stof(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMin));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else
				{
					cout << "Attribute does not contain numerical data" << endl;
					return "NULL";
				}
			}
			else
			{
				cout << "Attribute does not currently exist" << endl;
			}
		}
		else
		{
			return "NULL";
		}
	}

	string Table::max(string attributeName)
	{
		bool hasNonNullEntries = false;
		if (!rows.empty())
		{
			bool attributeExists = false;
			int attributeIndex;
			if (!attributeDefinitions.empty())
			{
				for (int i = 0; i < attributeDefinitions.size(); i++)
				{
					if (attributeName == attributeDefinitions[i].name)
					{
						if (attributeExists)
						{
							cout << "Duplicate index; returning 0" << endl;
							return 0;
						}
						attributeExists = true;
						attributeIndex = i;
					}
				}
			}
			if (attributeExists)
			{
				string attributeType = attributeDefinitions[attributeIndex].type;
				if (attributeType == "int")
				{
					int currentMax = INT_MIN;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stoi(currentValue) > currentMax)
							{
								currentMax = stoi(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMax));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else if (attributeType == "float")
				{
					float currentMax = INT_MIN;
					for (int i = 0; i < rows.size(); i++)
					{
						string currentValue = rows[i].attributes[attributeIndex];
						if (currentValue != "NULL")
						{
							hasNonNullEntries = true;
							if (stof(currentValue) > currentMax)
							{
								currentMax = stof(currentValue);
							}
						}
					}
					if (hasNonNullEntries)
					{
						return (to_string(currentMax));
					}
					else
					{
						cout << "No non-null values" << endl;
						return "NULL";
					}
				}
				else
				{
					cout << "Attribute does not contain numerical data" << endl;
					return "NULL";
				}
			}
			else
			{
				cout << "Attribute does not currently exist" << endl;
			}
		}
		else
		{
			return "NULL";
		}
	}
